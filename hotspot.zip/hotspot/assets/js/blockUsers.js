//block $(mac) insertBtn hide to selected User
var targetValues =
['233'
,'1222'
,'3443'
,'665'
,'1234'
,'1254'
,'1234'
,'12g4'
,'12gy4'
,'12gd'
,'yyytt'
,'6-&78'
,'565'
,'$(mac)'];
    
 
		   const input = document.querySelector('#macId');
    const button = document.querySelector('.insertBtn');
    function toggleButtonVisibility() {
     const value = input.innerText.trim();        
     if (!value) {
     button.style.display = 'inline-block';
     return;
      }            
    const values = value.split(',').map(v => v.trim());      
    const shouldHide = values.some(v => targetValues.includes(v));      
    button.style.display = shouldHide ? 'none' : 'inline-block';
    if (shouldHide) {
     }
  }setInterval(toggleButtonVisibility, 2000)		   
 	 window.onload = function () {
  document.getElementById('macId').focus();
}						   
		 input.addEventListener('focus', toggleButtonVisibility);	 		       
  input.addEventListener('change', toggleButtonVisibility);
		 input.addEventListener('keyup', toggleButtonVisibility);        
  // Initialize
   toggleButtonVisibility();

