insertBtnSwitch=true

msgSwitch1=true

msgSwitch2=false

msgLoginSwitch=true

extendVcSwitch=true

showPauseTime = true


const time = new Date().getHours(); // Get the current hour (0-23).
const today = new Date();
const christmasDay = new Date(today.getFullYear(), 11, 25); // month is 0-based (11 = December)
let greeting;


if (today.getMonth() === christmasDay.getMonth() && today.getDate() === christmasDay.getDate()) {
  greeting ="MERRY CHRISTMAS";
  FreeBtn=  "FREE CHRISTMAS GIFT";
  
}

else if (today.getMonth() === 0 && today.getDate() === 1) { 
  // month is 0-based (0 = January)
  greeting="HAPPY NEW YEAR"
}
else{
// Adjust the ranges for greetings
if (time >= 5 && time < 12) { 
  greeting = "GOOD MORNING !"; // Morning: 5 AM to 11:59 AM
} else if (time >= 12 && time < 18) {
  greeting = "GOOD AFTERNOON !"; // Afternoon: 12 PM to 5:59 PM
} else {
  greeting = "GOOD EVENING !"; // Evening: 6 PM to 4:59 AM
}


}


Message1=greeting;
Message2="OFFLINE SCHEDULE <br> TOMORROW"
//FreeBtn= "CLAIM PA XMASS 4HOURS"
FreeBtn=  "FREE Wi-Fi"


  


//msg1.style.backgroundColor="yellow"


//inserSwitch.style.display="none"