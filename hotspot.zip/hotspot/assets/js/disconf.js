
const rotatingTexts = [
{
elementId: "msgLogin",
messages: [
         "AVAILABLE HERE!",
         "PRINT | XEROX | SCAN | GCASH",
         "GCASH NUMBER : 0975 572 5109",
         "ENJOY 4G AND 5G CONNECTION",
         "HIGH SPEED WITH LONG RANGE 300M",
         "EXTEND TIME / PORTAL 10.0.0.1",
         "FREE-WIFI AY DI PWEDE I-EXTEND",
         "IF ERROR CLICK : CONNECT",
         "THANK YOU !",
    ],
currentIndex: 8 // Track the current index
},
{
elementId: "msgStatus",
messages: [
        "TIMER STARTS UPON CONNECTED",
         "EXTEND TIME / PORTAL 10.0.0.1",
         "FREE-WIFI AY DI PWEDE I-EXTEND",
         "IF ERROR CLICK : CONNECT",
         "AVAILABLE HERE!",
         "PRINT | XEROX | SCAN | GCASH",
         "GCASH NUMBER : 0975 572 5109",         
         "THANK YOU!",
 ],
currentIndex: 7 // Track the current index
}
];
// Function to rotate text
function rotateTexts() {
rotatingTexts.forEach((textGroup) => {
// Update the text content of the element
const element = document.getElementById(textGroup.elementId);
if (element) {
textGroup.currentIndex = (textGroup.currentIndex + 1) % textGroup.messages.length;
element.innerText = textGroup.messages[textGroup.currentIndex];
}
});
}
                  
// Start rotating every 3 seconds
setInterval(rotateTexts, 3000);




var insertBtnSwitch
if (!insertBtnSwitch){
inserSwitch.style.display="none"}



var msgSwitch1
if (!msgSwitch1){
msg1Switch.style.display="none"}


var msgSwitch2
if (!msgSwitch2){
   msg2Switch.style.display="none"
}else{
msgLogin.style.display="none"

}


var msgLoginSwitch
if (!msgLoginSwitch){
         msgLogin.style.display="none"
         
       }
var extendVcSwitch
if(!extendVcSwitch){
extendVc.style.display="none";

}

//free.style.backgroundColor="orange"

