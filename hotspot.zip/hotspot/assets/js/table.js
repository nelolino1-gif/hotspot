let users = [
{ amount: "₱5", time:"3h30m", valid: "3h30m" },
{ amount: "₱5", time:"1Gb", valid: "1d" },

{ amount: "₱150",time:"15d",valid: "15d" },
{ amount: " ₱300 ",time:"30d",valid: "30d" },

           
																												
												
												     
												    
												   
        ];


//wag gagalawin ang code sa ibaba

        // Get table elements
        const tableHeader = document.getElementById('tableHeader');
        const tableBody = document.getElementById('tableBody');

        // Function to create table header
        function createTableHeader() {
            const columns = ['Amount','Time | Data','Validity'];
            
            columns.forEach(column => {
                const th = document.createElement('th');
                th.textContent = column;
                tableHeader.appendChild(th);
            });
        }

        // Function to create table rows
        function createTableRows() {
            users.forEach(user => {
                // Create row
                const tr = document.createElement('tr');
                
                // Create amount cell
                const amountCell = document.createElement('td');
                amountCell.textContent = user.amount;
                amountCell.className = 'amount';
                tr.appendChild(amountCell);
                
                // Create time cell
                const timeCell = document.createElement('td');
                timeCell.textContent = user.time;
                timeCell.className = 'time';
                tr.appendChild(timeCell);
                
                // Create valid cell
                const validCell = document.createElement('td');
                validCell.textContent = user.valid;
                validCell.className = 'valid';
                tr.appendChild(validCell);
                
                
            /* const statusCell = document.createElement('td');
                statusCell.textContent = user.status;
                statusCell.className = 'status';
                tr.appendChild(statusCell); */
                
                // Add row to table body
                tableBody.appendChild(tr);
            });
        }

        // Initialize the table
        function initTable() {
            createTableHeader();
            createTableRows();
        }

        // Run when page loads
        document.addEventListener('DOMContentLoaded', initTable);
			
