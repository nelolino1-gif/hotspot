msgStatusSwitch= true

//pauseBtnSwitch= false
//var pauseBtnSwitch
//if (!pauseBtnSwitch){
//pauseSwitch.style.display="none"}

var msgStatusSwitch
if (!msgStatusSwitch){
msgStatus.style.display="none"}


var msgSwitch2
if (!msgSwitch2){
   msg2Switch.style.display="none"
}else{
msgStatus.style.display="none"

}